## how to use
compile all java files.

```java
javac *.java
```

exec MyApp
```
java -cp .:sqlite-jdbc-3.46.0.0.jar:slf4j-api-1.7.32.jar:slf4j-api-1.7.32.jar MyApp
```