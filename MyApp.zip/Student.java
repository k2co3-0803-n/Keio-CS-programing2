
public class Student {
	String studentID;
	String studentName;

	public Student(String studentID, String studentName) {
		this.studentID = studentID;
		this.studentName = studentName;
	}
	public String getStudentID() {
		return this.studentID;
	}
	public String getName() {
		return this.studentName;
	}
}